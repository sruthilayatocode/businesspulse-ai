import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import requests
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

load_dotenv()
BASE = Path(__file__).parent
DATA = BASE / "data"
DATA.mkdir(exist_ok=True)
DB_PATH = BASE / os.getenv("SQLITE_PATH", "data/businesspulse.db")

app = FastAPI(title="BusinessPulse AI", version="0.1.0")

EXPOSURES = [
    ("Taiwan Chip Partner", "supplier", "supply_chain", "Taiwan", 90, 14, 30, "Demo semiconductor dependency for Model 3 and Model Y"),
    ("China Battery Cell Partner", "supplier", "supply_chain", "China", 95, 21, 40, "Demo battery-cell dependency for Model Y"),
    ("Model Y", "product", "market", "United States", 85, 0, 40, "High-volume Tesla product in demo model"),
    ("BYD", "competitor", "competitor", "China", 70, 0, 30, "Competitor monitored for prices, launches and market share"),
    ("US EV Incentives", "regulation", "regulation", "United States", 80, 0, 35, "Demo policy exposure for customer demand and pricing"),
]

DEMO_ITEMS = [
    {
        "title": "Taiwan weather disruption affects semiconductor production schedules",
        "source_name": "Demo industry feed",
        "source_url": "https://example.com/taiwan-semiconductor-disruption",
        "content": "Severe weather has disrupted operations near key semiconductor facilities in Taiwan. Automotive chip supply schedules may be affected over the coming weeks.",
    },
    {
        "title": "New policy proposal could change electric vehicle incentives in the United States",
        "source_name": "Demo policy feed",
        "source_url": "https://example.com/us-ev-incentive-proposal",
        "content": "A proposed policy change may alter eligibility and value for electric vehicle consumer incentives in the United States.",
    },
    {
        "title": "BYD announces new electric vehicle pricing initiative in China",
        "source_name": "Demo competitor feed",
        "source_url": "https://example.com/byd-pricing-initiative",
        "content": "BYD announced a new pricing initiative for selected electric vehicle models in China, increasing competitive pressure in the market.",
    },
]

class Article(BaseModel):
    title: str = Field(min_length=5, max_length=1000)
    content: str = Field(min_length=20, max_length=15000)
    source_name: str = "Manual entry"
    source_url: str = ""

@contextmanager
def db():
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    try:
        yield connection
        connection.commit()
    finally:
        connection.close()

def initialize_database():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS tesla_exposure (
          exposure_id INTEGER PRIMARY KEY AUTOINCREMENT, entity_name TEXT, entity_type TEXT,
          category TEXT, region TEXT, dependency_score REAL, inventory_days REAL,
          revenue_weight REAL, notes TEXT
        );
        CREATE TABLE IF NOT EXISTS news_events (
          event_id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, source_url TEXT, source_name TEXT,
          published_at TEXT, event_type TEXT, entities TEXT, summary TEXT, severity REAL,
          urgency REAL, likelihood REAL, confidence REAL, status TEXT, created_at TEXT
        );
        CREATE TABLE IF NOT EXISTS event_exposure_map (
          map_id INTEGER PRIMARY KEY AUTOINCREMENT, event_id INTEGER, exposure_id INTEGER,
          match_confidence REAL, impact_path TEXT
        );
        CREATE TABLE IF NOT EXISTS risk_scores (
          risk_id INTEGER PRIMARY KEY AUTOINCREMENT, event_id INTEGER, priority_score REAL,
          priority_label TEXT, revenue_at_risk_usd REAL, recommended_action TEXT, calculated_at TEXT
        );
        """)
        count = con.execute("SELECT COUNT(*) FROM tesla_exposure").fetchone()[0]
        if count == 0:
            con.executemany("""INSERT INTO tesla_exposure
                (entity_name, entity_type, category, region, dependency_score, inventory_days, revenue_weight, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""", EXPOSURES)

def fallback_analysis(article: Article) -> dict[str, Any]:
    text = f"{article.title} {article.content}".lower()
    if any(w in text for w in ["chip", "semiconductor", "taiwan"]):
        return {"event_type": "supply_chain", "entities": ["Taiwan Chip Partner", "Taiwan", "semiconductors"], "summary": "Potential semiconductor supply disruption could affect Tesla vehicle production.", "severity": 82, "urgency": 78, "likelihood": 70, "confidence": 75, "recommended_action": "Confirm chip supplier shipment status, check 14-day inventory coverage, and assess approved alternatives."}
    if any(w in text for w in ["incentive", "tariff", "regulation", "policy"]):
        return {"event_type": "regulation", "entities": ["Tesla", "US EV Incentives", "United States"], "summary": "Policy change may affect Tesla demand, pricing, or compliance requirements.", "severity": 72, "urgency": 60, "likelihood": 65, "confidence": 72, "recommended_action": "Validate policy scope, model demand sensitivity, and prepare a pricing or customer-communication response."}
    return {"event_type": "competitor", "entities": ["Tesla", "BYD", "China"], "summary": "Competitor activity may increase pricing or market-share pressure on Tesla.", "severity": 65, "urgency": 55, "likelihood": 75, "confidence": 74, "recommended_action": "Compare competitor offer against Tesla positioning and review market-specific pricing response."}

def gemini_analysis(article: Article) -> dict[str, Any]:
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        return fallback_analysis(article)
    prompt = f'''You are BusinessPulse AI, an executive risk analyst monitoring Tesla. Analyze the news article below. Return JSON only with this exact shape:
{{"event_type":"supply_chain|market|competitor|regulation","entities":["..."],"summary":"max 35 words","severity":0-100,"urgency":0-100,"likelihood":0-100,"confidence":0-100,"recommended_action":"one practical action"}}
Focus only on material Tesla exposure. Do not invent facts.\n\nTITLE: {article.title}\nSOURCE: {article.source_name}\nARTICLE: {article.content}'''
    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    response = requests.post(
        f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}",
        headers={"Content-Type": "application/json"},
        json={"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"responseMimeType": "application/json", "temperature": 0.1}},
        timeout=45,
    )
    if not response.ok:
        raise HTTPException(502, f"Gemini analysis failed: {response.status_code}")
    try:
        text = response.json()["candidates"][0]["content"]["parts"][0]["text"]
        result = json.loads(text)
        required = {"event_type", "entities", "summary", "severity", "urgency", "likelihood", "confidence", "recommended_action"}
        if not required.issubset(result): raise ValueError("Incomplete model response")
        return result
    except (KeyError, IndexError, ValueError, json.JSONDecodeError) as error:
        raise HTTPException(502, f"Gemini returned invalid structured output: {error}")

def match_exposure(entities: list[str], event_type: str):
    with db() as con:
        candidates = con.execute("SELECT * FROM tesla_exposure WHERE category = ? OR entity_type = ?", (event_type, event_type)).fetchall()
        if not candidates:
            candidates = con.execute("SELECT * FROM tesla_exposure").fetchall()
    entity_text = " ".join(entities).lower()
    scored = []
    for row in candidates:
        overlap = 100 if row["entity_name"].lower() in entity_text or row["region"].lower() in entity_text else 65
        scored.append((dict(row), overlap))
    return max(scored, key=lambda x: x[0]["dependency_score"] * x[1])[0], max(scored, key=lambda x: x[0]["dependency_score"] * x[1])[1]

def priority_label(score: float) -> str:
    if score >= 80: return "Critical"
    if score >= 60: return "High"
    if score >= 35: return "Medium"
    return "Low"

def analyze_and_store(article: Article):
    analysis = gemini_analysis(article)
    exposure, match_confidence = match_exposure(analysis["entities"], analysis["event_type"])
    score = round(0.25 * analysis["severity"] + 0.35 * exposure["dependency_score"] + 0.20 * analysis["urgency"] + 0.10 * analysis["likelihood"] + 0.10 * analysis["confidence"], 1)
    revenue_risk = round(exposure["revenue_weight"] / 100 * 250_000_000 * score / 100, 0)
    impact_path = f"{article.title} -> {exposure['entity_name']} -> {exposure['notes']}"
    now = datetime.now(timezone.utc).isoformat()
    with db() as con:
        event_id = con.execute("""INSERT INTO news_events
          (title, source_url, source_name, published_at, event_type, entities, summary, severity, urgency, likelihood, confidence, status, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
          (article.title, article.source_url, article.source_name, now, analysis["event_type"], json.dumps(analysis["entities"]), analysis["summary"], analysis["severity"], analysis["urgency"], analysis["likelihood"], analysis["confidence"], "Open", now)).lastrowid
        con.execute("INSERT INTO event_exposure_map (event_id, exposure_id, match_confidence, impact_path) VALUES (?, ?, ?, ?)", (event_id, exposure["exposure_id"], match_confidence, impact_path))
        con.execute("""INSERT INTO risk_scores (event_id, priority_score, priority_label, revenue_at_risk_usd, recommended_action, calculated_at)
          VALUES (?, ?, ?, ?, ?, ?)""", (event_id, score, priority_label(score), revenue_risk, analysis["recommended_action"], now))
    return event_id

@app.on_event("startup")
def startup(): initialize_database()

@app.get("/")
def home(): return FileResponse(BASE / "static" / "index.html")

@app.get("/health")
def health(): return {"status": "ok", "company": "Tesla", "database": "sqlite demo; Exasol schema included"}

@app.get("/api/dashboard")
def dashboard():
    with db() as con:
        rows = con.execute("""SELECT e.event_id, e.title, e.event_type, e.summary, e.published_at, r.priority_score,
          r.priority_label, r.revenue_at_risk_usd, r.recommended_action FROM news_events e JOIN risk_scores r ON e.event_id=r.event_id
          ORDER BY r.priority_score DESC, e.event_id DESC""").fetchall()
    events = [dict(r) for r in rows]
    return {"company": "Tesla", "events": events, "metrics": {"critical": sum(e["priority_label"] == "Critical" for e in events), "high": sum(e["priority_label"] == "High" for e in events), "open_events": len(events), "estimated_revenue_at_risk_usd": sum(e["revenue_at_risk_usd"] for e in events)}}

@app.get("/api/briefing")
def briefing():
    data = dashboard(); events = data["events"][:5]
    summary = "No material events have been analyzed yet." if not events else " ".join(f"{e['priority_label']}: {e['summary']} Action: {e['recommended_action']}" for e in events)
    return {"company": "Tesla", "generated_at": datetime.now(timezone.utc).isoformat(), "summary": summary, "events": events}

@app.post("/api/events/analyze")
def analyze(article: Article):
    return {"event_id": analyze_and_store(article)}

@app.post("/api/demo/load")
def load_demo():
    with db() as con:
        if con.execute("SELECT COUNT(*) FROM news_events").fetchone()[0] > 0:
            return {"message": "Demo events are already loaded."}
    ids = [analyze_and_store(Article(**item)) for item in DEMO_ITEMS]
    return {"message": "Tesla demo events loaded.", "event_ids": ids}
