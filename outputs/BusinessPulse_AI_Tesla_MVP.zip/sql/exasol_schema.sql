CREATE SCHEMA IF NOT EXISTS BUSINESSPULSE;

CREATE TABLE IF NOT EXISTS BUSINESSPULSE.TESLA_EXPOSURE (
    exposure_id DECIMAL(18,0) IDENTITY,
    entity_name VARCHAR(200),
    entity_type VARCHAR(40),
    category VARCHAR(40),
    region VARCHAR(100),
    dependency_score DECIMAL(5,2),
    inventory_days DECIMAL(8,2),
    revenue_weight DECIMAL(5,2),
    notes VARCHAR(2000)
);

CREATE TABLE IF NOT EXISTS BUSINESSPULSE.NEWS_EVENTS (
    event_id DECIMAL(18,0) IDENTITY,
    title VARCHAR(1000),
    source_url VARCHAR(2000),
    source_name VARCHAR(200),
    published_at TIMESTAMP,
    event_type VARCHAR(40),
    entities VARCHAR(4000),
    summary VARCHAR(4000),
    severity DECIMAL(5,2),
    urgency DECIMAL(5,2),
    likelihood DECIMAL(5,2),
    confidence DECIMAL(5,2),
    status VARCHAR(30),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS BUSINESSPULSE.EVENT_EXPOSURE_MAP (
    map_id DECIMAL(18,0) IDENTITY,
    event_id DECIMAL(18,0),
    exposure_id DECIMAL(18,0),
    match_confidence DECIMAL(5,2),
    impact_path VARCHAR(4000)
);

CREATE TABLE IF NOT EXISTS BUSINESSPULSE.RISK_SCORES (
    risk_id DECIMAL(18,0) IDENTITY,
    event_id DECIMAL(18,0),
    priority_score DECIMAL(5,2),
    priority_label VARCHAR(20),
    revenue_at_risk_usd DECIMAL(18,2),
    recommended_action VARCHAR(4000),
    calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
